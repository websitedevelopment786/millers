<?php

// ================== One Click Demo Import ==================

function millers_import_files() {
    return [
        [
            'import_file_name'           => 'BlogZine Millers',
            'import_file_url'            => get_template_directory_uri() . '/inc/demo/content.xml',
            'import_preview_image_url'   => get_template_directory_uri() . '/inc/demo/preview.jpg',
            'import_customizer_file_url' => get_template_directory_uri() . '/inc/demo/customizer.dat',
            'required_plugins'           => ['elementor', 'header-footer-elementor', 'elementskit-lite', 'fluentform', 'add-to-any'],
            'preview_url'                => 'https://blogzine.wpskilla.com/',
        ]
    ];
}
add_filter('pt-ocdi/import_files', 'millers_import_files');


function millers_after_import_setup() {
    // Set home and blog pages
    $home = get_page_by_title('Home BlogZine');
    $blog = get_page_by_title('Blog BlogZine');
    
    if ($home) {
        update_option('page_on_front', $home->ID);
        update_option('show_on_front', 'page');
    }
    
    if ($blog) {
        update_option('page_for_posts', $blog->ID);
    }

    // Assign menus
    $menu = get_term_by('name', 'Main Menu BlogZine', 'nav_menu');
    if ($menu) {
        set_theme_mod('nav_menu_locations', ['primary' => $menu->term_id]);
    }

    // addtoany
    $addtoany_options = [
        "position" => "bottom",
        "display_in_posts_on_front_page" => "1",
        "display_in_posts_on_archive_pages" => "-1",
        "display_in_excerpts" => "-1",
        "display_in_posts" => "1",
        "display_in_pages" => "-1",
        "display_in_attachments" => "-1",
        "display_in_feed" => "1",
        "icon_size" => "32",
        "icon_bg" => "original",
        "icon_bg_color" => "#2a2a2a",
        "icon_fg" => "original",
        "icon_fg_color" => "#ffffff",
        "button" => "A2A_SVG_32",
        "button_custom" => "",
        "button_show_count" => "-1",
        "header" => "",
        "additional_js_variables" => "",
        "additional_css" => "",
        "custom_icons" => "-1",
        "custom_icons_url" => "/",
        "custom_icons_type" => "png",
        "custom_icons_width" => "",
        "custom_icons_height" => "",
        "cache" => "-1",
        "display_in_cpt_e-floating-buttons" => "-1",
        "display_in_cpt_elementor_library" => "-1",
        "display_in_cpt_elementskit_content" => "-1",
        "display_in_cpt_elementskit_template" => "-1",
        "display_in_cpt_elementor-hf" => "-1",
        "button_text" => "Share",
        "active_services" => ["facebook", "email", "pinterest", "whatsapp", "google_gmail", "x", "wordpress"],
        "special_facebook_like_options" => ["show_count" => "-1", "verb" => "like"],
        "special_twitter_tweet_options" => ["show_count" => "-1"],
        "special_pinterest_pin_options" => ["show_count" => "-1"],
        "special_pinterest_options" => ["show_count" => "-1"]
    ];
    update_option('addtoany_options', $addtoany_options);

    // Create new Elementor Kit and import styles
    millers_import_elementor_kit();
}
function millers_import_elementor_kit() {
    $kit_file_path = get_template_directory() . '/inc/demo/kit.json';
    
    if (file_exists($kit_file_path) && class_exists('Elementor\Plugin')) {
        // Decode kit data with error checking
        $kit_json = file_get_contents($kit_file_path);
        $kit_data = json_decode($kit_json, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('Kit JSON decode error: ' . json_last_error_msg());
            return;
        }

        // Build proper Elementor kit structure
        $elementor_data = [
            'version' => '3.0.0',
            'type' => 'kit',
            'title' => 'Theme Kit',
            'settings' => $kit_data['settings'],
            'content' => []
        ];

        // Get existing kits with improved query
        $existing_kits = get_posts([
            'post_type' => 'elementor_library',
            'post_status' => 'publish',
            'posts_per_page' => 1,
            'meta_key' => '_elementor_template_type',
            'meta_value' => 'kit'
        ]);

        // Prepare elementor data with proper content structure
        $encoded_data = wp_json_encode($elementor_data);
        if (!$encoded_data) {
            error_log('Elementor data encoding failed');
            return;
        }

        if (empty($existing_kits)) {
            // Create new kit with proper post meta
            $new_kit = wp_insert_post([
                'post_title' => 'Theme Kit',
                'post_type' => 'elementor_library',
                'post_status' => 'publish',
                'meta_input' => [
                    '_elementor_template_type' => 'kit',
                    '_elementor_data' => wp_slash($encoded_data),
                    '_elementor_edit_mode' => 'builder',
                    '_elementor_version' => ELEMENTOR_VERSION
                ]
            ]);

            if (!is_wp_error($new_kit)) {
                update_option('elementor_active_kit', $new_kit);
            }
        } else {
            // Update existing kit with new data
            $kit_id = $existing_kits[0]->ID;
            update_post_meta(
                $kit_id,
                '_elementor_data',
                wp_slash($encoded_data)
            );
            update_option('elementor_active_kit', $kit_id);
        }

        // Flush Elementor cache properly
        \Elementor\Plugin::$instance->files_manager->clear_cache();
        update_option('_elementor_flush_needed', 'yes');
    }
}
add_action('pt-ocdi/after_import', 'millers_after_import_setup');
add_action('ocdi/after_import', 'millers_after_import_setup');













