<?php

function get_url_content_func() {
    if (!isset($_POST['url'])) {
        wp_send_json_error('No URL provided.');
    }

    $url = esc_url_raw($_POST['url']);

    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        wp_send_json_error('Invalid URL format.');
    }

    $html = @file_get_contents($url);

    if ($html === false) {
        wp_send_json_error('Failed to fetch content.');
    }

    wp_send_json_success($html); // Convert HTML special chars to safe display
}

add_action('wp_ajax_get_url_content_func', 'get_url_content_func');
add_action('wp_ajax_nopriv_get_url_content_func', 'get_url_content_func');

function insert_new_post() {
    if (!isset($_POST['title']) || !isset($_POST['content'])) {
        wp_send_json_error(['message' => 'Title or content missing']);
    }

    // title/author/date/content/cats/thumbnail/tags/comments
    $post_title = sanitize_text_field($_POST['title']);
    $post_content = stripslashes($_POST['content']); // Prevent escape issues
    $thumb_url = isset($_POST['thumb']) ? esc_url_raw($_POST['thumb']) : '';
    $taxo_list = isset($_POST['taxo_list']) ? explode(',', sanitize_text_field($_POST['taxo_list'])) : [];

    // Define allowed HTML tags (including iframe, embed, video, and images)
    $allowed_html = [
        'p' => [], 'br' => [], 'strong' => [], 'em' => [], 'u' => [], 'b' => [], 'i' => [],
        'a' => ['href' => [], 'title' => [], 'target' => []],
        'img' => ['src' => [], 'alt' => [], 'width' => [], 'height' => [], 'class' => []],
        'iframe' => ['src' => [], 'width' => [], 'height' => [], 'frameborder' => [], 'allow' => []],
        'embed' => ['src' => [], 'width' => [], 'height' => [], 'allowfullscreen' => []],
        'video' => ['src' => [], 'controls' => [], 'autoplay' => [], 'loop' => [], 'muted' => []],
        'audio' => ['src' => [], 'controls' => []],
        'h1' => [], 'h2' => [], 'h3' => [], 'h4' => [], 'h5' => [], 'h6' => [],
        'ul' => [], 'ol' => [], 'li' => [],
        'blockquote' => [], 'pre' => [],
        'table' => [], 'tr' => [], 'td' => [], 'th' => [], 'thead' => [], 'tbody' => [], 'tfoot' => [],
        'div' => ['class' => [], 'id' => [], 'style' => []],
        'span' => ['class' => [], 'id' => [], 'style' => []],
        'code' => [], 'kbd' => [], 'samp' => [], 'var' => [],
        'script' => ['type' => [], 'src' => []] // Optional, use with caution
    ];
    // Sanitize content while keeping necessary HTML
    $post_content = wp_kses($post_content, $allowed_html);

    // Check if a post with the same title already exists
    $existing_post = get_page_by_title($post_title, OBJECT, 'post');
    if ($existing_post) {
        wp_send_json_error(['message' => 'Duplicate post detected. Post not inserted.']);
    }

    $post_data = [
        'post_title'    => $post_title,
        'post_content'  => $post_content,
        'post_status'   => 'publish',  // Publish immediately
        'post_author'   => 1,
        'post_category' => [1],  // Default category (change as needed)
    ];

    $post_id = wp_insert_post($post_data);

    if (is_wp_error($post_id)) {
        wp_send_json_error(['message' => 'Failed to insert post']);
    }

    // Download & set featured image if thumbnail URL is provided
    if (!empty($thumb_url)) {
        $thumb_id = download_and_attach_image($thumb_url, $post_id);
        if ($thumb_id) {
            set_post_thumbnail($post_id, $thumb_id);
        }
    }

    // Automatically download & replace external images
    $post_content = download_and_replace_images($post_content, $post_id);
    wp_update_post(['ID' => $post_id, 'post_content' => $post_content ]);

    if (!empty($taxo_list)) {
        $categories = [];
        $tags = [];
        $half_count = ceil(count($taxo_list) / 2);
        
        foreach ($taxo_list as $index => $taxo) {
            $taxo = trim($taxo);
            if (!empty($taxo)) {
                $term = term_exists($taxo, 'category');
                if (!$term) {
                    $new_term = wp_insert_term($taxo, 'category');
                    if (!is_wp_error($new_term)) {
                        $categories[] = $new_term['term_id'];
                    }
                } else {
                    $categories[] = $term['term_id'];
                }
                
                if ($index < $half_count) {
                    $tag_term = term_exists($taxo, 'post_tag');
                    if (!$tag_term) {
                        $new_tag = wp_insert_term($taxo, 'post_tag');
                        if (!is_wp_error($new_tag)) {
                            $tags[] = $new_tag['term_id'];
                        }
                    } else {
                        $tags[] = $tag_term['term_id'];
                    }
                }
            }
        }
        wp_set_post_categories($post_id, $categories);
        wp_set_post_terms($post_id, $tags, 'post_tag');
    }

    wp_send_json_success(['message' => 'Post inserted successfully', 'post_id' => $post_id]);
}
add_action('wp_ajax_insert_new_post', 'insert_new_post');
add_action('wp_ajax_nopriv_insert_new_post', 'insert_new_post');

function download_and_replace_images($post_content, $post_id) {
    if (preg_match_all('/<img.*?src=["\'](.*?)["\']/', $post_content, $matches)) {
        foreach ($matches[1] as $image_url) {
            $image_id = download_and_attach_image($image_url, $post_id);
            if ($image_id) {
                // Replace external image URL with WordPress media URL
                $wp_image_url = wp_get_attachment_url($image_id);
                $post_content = str_replace($image_url, $wp_image_url, $post_content);
            }
        }
    }
    return $post_content;
}

function download_and_attach_image($image_url, $post_id) {
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');

    // Validate URL
    if (empty($image_url) || !filter_var($image_url, FILTER_VALIDATE_URL)) {
        return false;
    }

    // Download the image to a temporary location
    $file = download_url($image_url);

    if (is_wp_error($file)) {
        return false;
    }

    // Prepare file array
    $file_array = [
        'name'     => basename($image_url),
        'tmp_name' => $file
    ];

    // Upload the image to the WordPress media library
    $attachment_id = media_handle_sideload($file_array, $post_id);

    // Check for errors
    if (is_wp_error($attachment_id)) {
        @unlink($file);
        return false;
    }

    // Set featured image (optional)
    set_post_thumbnail($post_id, $attachment_id);

    return $attachment_id;
}



