<!-- Temp | WP Scraper -->

<style type="text/css">
.this_flex {display: flex;}
#scrapedContent, #scrapedUrls, #postContent {width: 32%;border: 5px solid;}
</style>

<form id="scrapeForm">
    <input type="text" id="scrapeUrl" placeholder="Enter URL" required style="width: 100%;">
    <button type="submit">Fetch Content</button>
</form>
<a id="this_pagination" href="#" target="_blank"></a><br>
<a id="this_page" href="#" target="_blank"></a><br><br>
<div class="this_flex">
    <div id="scrapedContent"></div>
    <div id="scrapedUrls"></div>
    <div id="postContent"></div>
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
    $(document).ready(function() {
        
        document.getElementById('scrapeForm').addEventListener('submit', function(e) {
            e.preventDefault();
            let startPage = <?php echo isset($_GET['pg']) ? (int)$_GET['pg'] : 1; ?>;
            let url = document.getElementById('scrapeUrl').value;
            document.getElementById('this_pagination').innerText = url;
            scrapePage(url, startPage);
        });

        function scrapePage(baseUrl, page) {
            let pageUrl = page === 1 ? baseUrl : `${baseUrl}page/${page}/`;
            console.log(`Fetching: ${pageUrl}`);
            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    'action': 'get_url_content_func',
                    'url': pageUrl
                })
            })
            .then(response => response.json())
            .then(data => {
                let parser = new DOMParser();
                let doc = parser.parseFromString(data.data, 'text/html');
                doc.querySelectorAll('script, style').forEach(el => el.remove());
                // page html
                let bodyContent = doc.body.innerHTML;
                document.getElementById('scrapedContent').innerHTML = bodyContent;
                // post links arr
                let postLinks = [];
                $('#scrapedContent').find('.wp-block-query .wp-block-post-title a').each(function() {
                    postLinks.push($(this).attr('href'));
                });
                console.log('All post links =>', postLinks);
                document.getElementById('scrapedUrls').innerHTML = postLinks.map(link => `<span>${link}</span>`).join(' ');
                // go next page
                if (postLinks.length > 0) {
                    processPosts(postLinks, 0, baseUrl, page);
                    // document.getElementById('this_pagination').innerText = baseUrl + 'page/' + (page+1) + '/';
                    // setTimeout(() => scrapePage(baseUrl, (page+1)), 2000);
                }
            }).catch(error => console.error('Error:', error));
        }

        function processPosts(postLinks, index, baseUrl, page) {
            if (index >= postLinks.length) {
                console.log("All posts processed, moving to next page.");
                setTimeout(() => scrapePage(baseUrl, page + 1), 2000);
                return;
            }

            let postUrl = postLinks[index];
            console.log(`Fetching Post: ${postUrl}`);

            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    'action': 'get_url_content_func',
                    'url': postUrl
                })
            })
            .then(response => response.json())
            .then(data => {
                let parser = new DOMParser();
                let doc = parser.parseFromString(data.data, 'text/html');
                doc.querySelectorAll('script, style').forEach(el => el.remove());
                // post html
                let postContent = doc.body.innerHTML;
                document.getElementById('postContent').innerHTML = postContent;
                // post arg
                let post_title = $('#postContent main').find('.wp-block-post-title').text() || 'Untitled Post';
                let post_content = $('#postContent main').find('.wp-block-post-content').html() || "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";
                let post_thumb = $('#postContent main').find('.wp-block-post-featured-image img').attr('src') || null;
                if (post_thumb) {post_thumb = post_thumb.split('?')[0];}
                // taxonomies
                let taxo_list = [];
                $('#postContent main').find('.taxonomy-category a').each(function() {
                    taxo_list.push($(this).text());
                });
                // inset post
                insertPost(post_title, post_content, post_thumb, taxo_list, () => {
                    // console.log('go for next post');
                    processPosts(postLinks, index + 1, baseUrl, page);
                });
            })
            .catch(error => console.error('Error:', error));
        }

        function insertPost(title, content, post_thumb, taxo_list, callback) {
            console.log(`Inserting Post: ${title}`);

            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    'action': 'insert_new_post',
                    'title': title,
                    'content': content,
                    'thumb': post_thumb,
                    'taxo_list': taxo_list,
                })
            })
            .then(response => response.json())
            .then(data => {
                console.log("Post Inserted:", data);
                callback(); // Proceed to the next post
            })
            .catch(error => console.error('Error inserting post:', error));
        }

    });
</script>

