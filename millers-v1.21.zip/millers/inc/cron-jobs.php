<?php 


// logs
function log_cleanup_process($message) {
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log($message);
    }
}

// init schedule
function schedule_daily_cleanup() {
    if (!wp_next_scheduled('daily_orphan_data_cleanup')) {
        wp_schedule_event(time(), 'daily', 'daily_orphan_data_cleanup');
    }
    if (!wp_next_scheduled('cleanup_unused_images_cron')) {
        wp_schedule_event(time(), 'daily', 'cleanup_unused_images_cron');
    }
}
add_action('init', 'schedule_daily_cleanup');

// func daily_orphan_data_cleanup
function run_orphan_data_cleanup() {
    global $wpdb;

    log_cleanup_process('Starting orphan data cleanup.');

    // Batch processing for orphan postmeta cleanup
    $batch_size = 100;
    $offset = 0;
    do {
        $posts_to_delete = $wpdb->get_col("SELECT post_id FROM {$wpdb->postmeta} WHERE post_id NOT IN (SELECT ID FROM {$wpdb->posts}) LIMIT $batch_size OFFSET $offset");
        if (!empty($posts_to_delete)) {
            $placeholders = implode(',', array_fill(0, count($posts_to_delete), '%d'));
            $wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE post_id IN ($placeholders)", $posts_to_delete);
            $offset += $batch_size;
            log_cleanup_process('Deleted orphan postmeta in batch.');
        }
    } while (!empty($posts_to_delete));

    // Orphan commentmeta cleanup
    $batch_size = 100;
    $offset = 0;
    do {
        $comments_to_delete = $wpdb->get_col("SELECT comment_id FROM {$wpdb->commentmeta} WHERE comment_id NOT IN (SELECT comment_ID FROM {$wpdb->comments}) LIMIT $batch_size OFFSET $offset");
        if (!empty($comments_to_delete)) {
            $placeholders = implode(',', array_fill(0, count($comments_to_delete), '%d'));
            $wpdb->query("DELETE FROM {$wpdb->commentmeta} WHERE comment_id IN ($placeholders)", $comments_to_delete);
            $offset += $batch_size;
            log_cleanup_process('Deleted orphan commentmeta in batch.');
        }
    } while (!empty($comments_to_delete));

    // Orphan usermeta cleanup
    $batch_size = 100;
    $offset = 0;
    do {
        $users_to_delete = $wpdb->get_col("SELECT user_id FROM {$wpdb->usermeta} WHERE user_id NOT IN (SELECT ID FROM {$wpdb->users}) LIMIT $batch_size OFFSET $offset");
        if (!empty($users_to_delete)) {
            $placeholders = implode(',', array_fill(0, count($users_to_delete), '%d'));
            $wpdb->query("DELETE FROM {$wpdb->usermeta} WHERE user_id IN ($placeholders)", $users_to_delete);
            $offset += $batch_size;
            log_cleanup_process('Deleted orphan usermeta in batch.');
        }
    } while (!empty($users_to_delete));

    // Orphan termmeta cleanup
    $batch_size = 100;
    $offset = 0;
    do {
        $terms_to_delete = $wpdb->get_col("SELECT term_id FROM {$wpdb->termmeta} WHERE term_id NOT IN (SELECT term_id FROM {$wpdb->terms}) LIMIT $batch_size OFFSET $offset");
        if (!empty($terms_to_delete)) {
            $placeholders = implode(',', array_fill(0, count($terms_to_delete), '%d'));
            $wpdb->query("DELETE FROM {$wpdb->termmeta} WHERE term_id IN ($placeholders)", $terms_to_delete);
            $offset += $batch_size;
            log_cleanup_process('Deleted orphan termmeta in batch.');
        }
    } while (!empty($terms_to_delete));

    // Orphan term relationships cleanup
    $wpdb->query("DELETE FROM {$wpdb->term_relationships} WHERE object_id NOT IN (SELECT ID FROM {$wpdb->posts})");

    // Remove expired transients
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_%' AND option_value < UNIX_TIMESTAMP()");

    // Remove all transients
    $transient_options = $wpdb->get_col("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_%' OR option_name LIKE '\_site_transient\_%'");
    if (!empty($transient_options)) {
        foreach ($transient_options as $option_name) {
            if (strpos($option_name, '_site_transient_') !== false) {
                delete_site_transient(str_replace('_site_transient_', '', $option_name));
            } else {
                delete_transient(str_replace('_transient_', '', $option_name));
            }
        }
    }

    // Remove transients marked for autoload
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE autoload = 'yes' AND option_name LIKE '_transient_%'");

    // Remove spam comments
    $spam_comments = $wpdb->get_col("SELECT comment_ID FROM {$wpdb->comments} WHERE comment_approved = 'spam'");
    if (!empty($spam_comments)) {
        foreach ($spam_comments as $comment_id) {
            wp_delete_comment((int) $comment_id, true);
        }
    }

    // Remove trashed comments
    $trashed_comments = $wpdb->get_col("SELECT comment_ID FROM {$wpdb->comments} WHERE comment_approved IN ('trash', 'post-trashed')");
    if (!empty($trashed_comments)) {
        foreach ($trashed_comments as $comment_id) {
            wp_delete_comment((int) $comment_id, true);
        }
    }

    // Remove orphaned _oembed_* postmeta (where post_id = 0)
    $wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE post_id = 0 AND meta_key LIKE '_oembed_%'");

    // Define tables to optimize dynamically using the WordPress prefix
    $tables = [
        $wpdb->posts,
        $wpdb->postmeta,
        $wpdb->comments,
        $wpdb->commentmeta,
        $wpdb->users,
        $wpdb->usermeta,
        $wpdb->terms,
        $wpdb->termmeta,
        $wpdb->term_relationships,
        $wpdb->options
    ];

    // Exclude very large plugin tables like WooCommerce dynamically
    $excluded_tables = [
        $wpdb->prefix . 'woocommerce_order_items',
        $wpdb->prefix . 'woocommerce_order_itemmeta'
    ];

    foreach ($tables as $table) {
        if (!in_array($table, $excluded_tables)) {
            // Check table fragmentation before optimizing
            $analyze = $wpdb->get_results("ANALYZE TABLE $table");
            if (!empty($analyze) && strpos($analyze[0]->Msg_text, 'Table is already up to date') === false) {
                $wpdb->query("OPTIMIZE TABLE $table");
                log_cleanup_process("Optimized table: $table.");
            }
        }
    }

    // Log last cleanup time (optional)
    update_option('last_orphan_cleanup', current_time('mysql'));

    log_cleanup_process('Orphan data cleanup completed.');
}
add_action('daily_orphan_data_cleanup', 'run_orphan_data_cleanup');

// func cleanup_unused_images_cron
function cleanup_unused_images() {
    global $wpdb;
    $upload_dir = wp_get_upload_dir();
    $base_dir = $upload_dir['basedir'];

    // List of sizes to remove
    $unused_sizes = ['medium_large', '1536x1536', '2048x2048'];

    // Get all media attachments
    $attachments = $wpdb->get_results("SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment'");

    foreach ($attachments as $attachment) {
        $meta = wp_get_attachment_metadata($attachment->ID);

        if ($meta && isset($meta['sizes'])) {
            foreach ($unused_sizes as $size) {
                if (isset($meta['sizes'][$size])) {
                    $file_path = $base_dir . '/' . dirname($meta['file']) . '/' . $meta['sizes'][$size]['file'];
                    
                    if (file_exists($file_path)) {
                        @unlink($file_path); // Delete file
                    }
                }
            }
        }
    }

    update_option('last_images_cleanup', current_time('mysql'));

    log_cleanup_process('Starting images cleanup.');
}
add_action('cleanup_unused_images_cron', 'cleanup_unused_images');

// end schedule
function unschedule_daily_cleanup() {
    $timestamp = wp_next_scheduled('daily_orphan_data_cleanup');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'daily_orphan_data_cleanup');
    }
    $timestamp2 = wp_next_scheduled('cleanup_unused_images_cron');
    if ($timestamp2) {
        wp_unschedule_event($timestamp2, 'cleanup_unused_images_cron');
    }
}
add_action('switch_theme', 'unschedule_daily_cleanup');









